<?php session_start();

if (!isset($_SESSION['1user'])) {
	// code...
	echo "PLease Login Again";
	echo "<a href='login.php'>Click Login</a>";
}else
{
	$now=time();
	if ($now > $_SESSION['expire']) {
		// code...
		session_destroy();
		echo "Your Session Expire <a href='login.php'>Click Login</a>";
	}else
	{
		echo "Welcome";
	}
}

 ?>
<html>


<?php 
echo $_SESSION['1user'];

echo "Your Session Expire <a href='logout.php'>Click Logout</a>";

  ?>


</html>
 