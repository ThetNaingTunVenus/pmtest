<?php 

session_start();

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<title></title>
 </head>
 <body>
 
<form name="form1" method="post">
	<table>
		<tr>
			<td>Username</td>
			<td><input type="text" name="text1"></td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password" name="pwd"></td>
		</tr>
		<tr>
			<td><input type="submit" name="submit1" value="SignIn"></td>
			
		</tr>
	</table>
</form>

 </body>
 </html>


<?php 

if(@$_POST['submit1'])
{
	$u=$_POST['text1'];
	$p=$_POST['pwd'];
	if ($u == "admin" && $p == "admin") {
		// code...
		$_SESSION['1user'] = $u;
		$_SESSION['start'] = time();
		$_SESSION['expire'] = $_SESSION['start']+(30*60);
		header('Location:homepage.php');
	}else
	{
		echo "Please Enter Username and Password";
	}
}

 ?>



